<?php
    echo "<h1>Hola Bones! Aquest és un programa de prova d'Adrià i Dereck</h1>";
    echo "<h4>Intentant realitzar la connexió amb la base de dades...</h4>";

    // Define los parámetros de conexión a la base de datos
    $host = 'mysql';
    $usuari = 'root';
    $psswd = 'rootpassword';
    
    // Establece la conexión utilizando mysqlnd
    $conn = mysql_connect($host, $usuari, $psswd);

    // Verifica si la conexión fue exitosa
    if (!$conn) {
        die("La connexió ha fallat: " . mysql_error());
    } else {
        echo "La connexió a MySQL s'ha realitzat correctament!";
    }
?>

